import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
*Classe heritant d'un JFrame, contenant le premier Menu.
*@author Vieira Kermarrec
*/
 
public class Menuun extends JFrame{
    /**
    *bouton pour lancer une partie.
    */
    private JButton jouer=new JButton("COMMENCER");
    /**
    *bouton pour lancer une partie sauvegarder dans un ficher.
    */
    private JButton reprendre=new JButton("REGLES DU JEU");
    /**
    *bouton pour quitter le jeu.
    */
    private JButton quitter=new JButton("QUITTER");

  /**
  *Constructeur de la classe Menuun, il ajoute les boutons au JFrame sur un GridLayout(4,1);
  */
  Color Purple = new Color(183,101,199);
  public Menuun(){
    this.setTitle("Menu");
    Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    int height = (int)dimension.getHeight();
    int width  = (int)dimension.getWidth();
    this.setSize(width, height);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLocationRelativeTo(null);
    this.jouer.setForeground(Color.BLACK);
    this.jouer.setBackground(Purple);
    this.jouer.setPreferredSize(new Dimension(300, 70));
    this.reprendre.setForeground(Color.BLACK);
    this.reprendre.setBackground(Purple);
    this.reprendre.setPreferredSize(new Dimension(300, 70));
    this.quitter.setForeground(Color.BLACK);
    this.quitter.setBackground(Purple);
    this.quitter.setPreferredSize(new Dimension(300, 70));
    GridLayout grille=new GridLayout(4,1);
        JLabel titre=new JLabel("Puissance Royale");
    Font font = new Font("Helvetica",Font.BOLD,70);
    titre.setFont(font);
    titre.setForeground(Color.WHITE);
    this.setLayout(grille);
    for(int i=0;i<4;i++){
      if(i==0){
        PanPan pan=new PanPan(1);
        pan.add(titre);
        this.add(pan);
      }if(i==1){
        PanPan pan2=new PanPan(2);
        pan2.add(jouer);
        this.add(pan2);
      }if(i==2){
        PanPan pan3=new PanPan(3);
        pan3.add(reprendre);
        this.add(pan3);
      }if(i==3){
        PanPan pan4=new PanPan(4);
        pan4.add(quitter);
        this.add(pan4);
      }
    }
    this.setVisible(true);
  }

}

