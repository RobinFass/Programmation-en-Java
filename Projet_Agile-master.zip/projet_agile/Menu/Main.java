import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
/**
*Classe contenant le main.
*@author Vieira Kermarrec
*/
public class Main{
	/**
	*main, utilise un pack Java pour avoir un design different sur certains boutons.
	*/
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		}catch(ClassNotFoundException e1){
			System.out.println("Ce LookAndFeel n'existe pas");
			System.exit(0);
		}
		catch(InstantiationException e2){}
		catch(IllegalAccessException e3){}
		catch(UnsupportedLookAndFeelException e4){}
		catch(ClassCastException e5){
			System.out.println("PAS BON");
			System.exit(0);
		}
		Menuun men=new Menuun();
	}
}
