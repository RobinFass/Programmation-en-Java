import java.awt.*;
import javax.swing.*;
/**
*Classe heritant d'un JPanel, elle permet de creer un fond d'ecran pour nos menus.
*@author Vieira Kermarrec
*/
public class PanPan extends JPanel{
private int ph;
private Image image1;//4 images constituant une meme image assembler sur un GridLayout.
private Image image2;
private Image image3;
private Image image4;
private Image image5;
   public PanPan(int nb){
     this.ph=nb;
     image1=(new javax.swing.ImageIcon(getClass().getResource("/fond1.jpg"))).getImage();
     image2=(new javax.swing.ImageIcon(getClass().getResource("/fond2.jpg"))).getImage();
     image3=(new javax.swing.ImageIcon(getClass().getResource("/fond3.jpg"))).getImage();
     image4=(new javax.swing.ImageIcon(getClass().getResource("/fond4.jpg"))).getImage();
     image5=(new javax.swing.ImageIcon(getClass().getResource("/tITRE.png"))).getImage();
   }

  /**
  *Dessine nos images.
  */
   public void paintComponent(Graphics g)
   {

     super.paintComponent(g);
     if(this.ph==1){
       g.drawImage (this.image1,0,0,getWidth(),getHeight(), this);
     }
     if(this.ph==2){
       g.drawImage (this.image2,0,0,getWidth(),getHeight(), this);
     }
     if(this.ph==3){
       g.drawImage (this.image3,0,0,getWidth(),getHeight(), this);
     }
     if(this.ph==4){
       g.drawImage (this.image4,0,0,getWidth(),getHeight(), this);
     }
     if(this.ph==5){
       g.drawImage (this.image5,0,0,150,150, this);
     }
   }
  }
