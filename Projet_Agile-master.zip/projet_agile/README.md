Voila le battle royale du puissance 4. 

Pour lancer le jeu il faut faire dans le repertoire src un : "javac *.java"    puis un "java Main"

Profitez bien du jeu !!!
A consommer sans modération !

Adam SIDHOUM, Robin FASSELER, Enzo VIEIRA, Florian CORBIER et Erwan KERMARRCK 