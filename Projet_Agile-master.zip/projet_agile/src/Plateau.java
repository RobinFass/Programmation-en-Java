import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class Plateau implements MouseListener{
    /*
     * Fonctionnement :
     * - Mise en place d'un background en bleu
     * - Ajout des pions du puissance 4 un a un (suite à suite) 
     * - Tout les composants sont dessiné
     * - Hauteur : 600px
     * - Largeur : 650px
     * VuePlateau = pion
     */
    private int gX = 650; //X de la grille
    private int gY = 600; //Y de la grille
    private int gapL = 10; //Espacement entre les pions (largeur)
    private int gapH = 15; //Espacement entre les pions (hauteur)
    private int pDim = 75; //Dimension d'un pion (côté)
    private JFrame fenetre = new JFrame();
    private JLabel GameHolder = new JLabel("Init"); //Label qui contiendras les informations sur le statut de jeu
    private JPanel playedGrid = new JPanel(); //Cette partie contient la grille du jeu
    private int nPlaying = 1; //Stock quel joueur doit jouer
    private Pow4 gEngine; //Permet d'appeler une clone de la fonction "engine" et qui soit utilisable partout dans le code
    // private int[] jstate = new int[2]; //Contient les numéros de joueurs ayant déjà gagné (deux victoires possibles avant fin de partie)
    // private int played;
    private boolean canPlay = true; //Permet de savoir si la partie est finie ou non. false = partie finie
    private String[] CcodeP = new String[3]; //Retourne une valeurs string de la couleur associé à chaque joueur
    Plateau(Pow4 engine, int pCount) {
        CcodeP[0]="VERT"; CcodeP[1]="ROUGE"; CcodeP[2]="ORANGE"; //Attribution des couleurs par joueurs
        gEngine = engine;
        fenetre.setSize(gX,gY+20);
        fenetre.setLocation(0,0);
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        playedGrid.setSize(gX, gY);
        playedGrid.setBackground(Color.BLUE);
        GridLayout gestionnaire = new GridLayout(6,7,gapH,gapL);
        updateFrame(); //Appel de la fonction pour dessiner la grille
        playedGrid.setLayout(gestionnaire);
        playedGrid.addMouseListener(this);
        setPlayerHolder("Nombre de joueur : "+pCount + " | >> C'est au joueur " +nPlaying+" de jouer ! (Couleur : " + CcodeP[(nPlaying-1)] + " )");
        fenetre.add(playedGrid, BorderLayout.CENTER);
        fenetre.add(GameHolder, BorderLayout.SOUTH);
        fenetre.setResizable(false);
        fenetre.setVisible(true);
    }
    public void mousePressed(MouseEvent e){
        //X = Colone
        //Y = Ligne
        // System.out.println("CanPlay :" + canPlay);
        if(canPlay){
            int tmp = gEngine.place(getCol(e.getX()), nPlaying); //Placement du pion
            //System.out.println(canPlay + " - " + gEngine.getNumberOfWinner());
            if(tmp==0){ //Emplacement libre
                nPlaying++;
                updateFrame();
                updatePlayer();
            }else if(tmp!=-1 && tmp!=-2){
                //Le joueur qui vient de jouer vient de gagner
                if(gEngine.getNumberOfWinner()==0){
                    nPlaying++;
                    gEngine.getWinner()[0]=tmp;
                }else if(gEngine.getNumberOfWinner()==1){
                    nPlaying++;
                    gEngine.getWinner()[1]=tmp;
                }else if(tmp==nPlaying){
                    //Signe déclencheur de fin de partie, le joueur n'a pas été incrémenté
                    //canPlay=false;
                    
                    if(gEngine.getNumberOfWinner()==2){
                    	canPlay=false;
                    	new BlobFrame("Le joueur "+gEngine.getWinner()[0]+" est le 1er a avoir gagné (Couleur : " + CcodeP[(gEngine.getWinner()[0]-1)] + " ) ","Le joueur "+gEngine.getWinner()[1]+" est le 2eme a avoir gagné (Couleur : " + CcodeP[(gEngine.getWinner()[1]-1)] + " )", "Fin de partie/Victoire");
                    }
                }
                updatePlayer();
                updateFrame();
                setPlayerHolder("LE JOUEUR "+gEngine.getWinner()[gEngine.getNumberOfWinner()-1]+ " VIENT DE GAGNER LA PARTIE, | JOUEUR SUIVANT : "+nPlaying+ "(Couleur : " + CcodeP[(nPlaying-1)] + " )");
            }else if(tmp==-1){canPlay=false;} //Double win, fin de partie
            else
                setPlayerHolder("[JOUEUR " + nPlaying +"] Impossible de placer le pion ici");
        }else{
            setPlayerHolder("LA PARTIE EST FINIE !");
        }
    }
    //Fonction réglementaire & nécessaire
    public void mouseReleased(MouseEvent e)
    {
    }
    //Fonction réglementaire & nécessaire
    public void mouseExited(MouseEvent e)
    {
    }
    //Fonction réglementaire & nécessaire
    public void mouseEntered(MouseEvent e)
    {
    }
    //Fonction réglementaire & nécessaire
    public void mouseClicked(MouseEvent e)
    {
    }
    //Cette fonction permet de déterminer la colone où le joueur vient de cliquer 
    private int getCol(int X){
        for(int i=1; i<8; i++){
            //Fais une boucle et vérifie que les coordonées où clique le joueur sont comprise entre une range calculé à la volé en fonction des dimensions de la fenêtre, de la grille et de la taille des pions
            if(((i+1)*pDim+((i+1)*(gapH+2)))>=X && ((i)*pDim+((i)*(gapH+2)))<=X){
                return i;
            }
        }
        return 0;
    }
    //Cette fonction permet de déterminer la ligne où le joueur vient de cliquer 
    private int getLigne(int Y){
        for(int i=1; i<8; i++){
            //Fais une boucle et vérifie que les coordonées où clique le joueur sont comprise entre une range calculé à la volé en fonction des dimensions de la fenêtre, de la grille et de la taille des pions
            if(((i+1)*pDim+((i+1)*(2*gapL)))>=Y && ((i)*pDim+((i)*(2*gapL)))<=Y){
                return i;
            }
        }
        return 0;
    }
    //Met à jour la grille quand un joueur place un pion dessus
    private void updateFrame(){
        playedGrid.removeAll();
        for (int i=0;i<6;i++){
            for (int y=0;y<7;y++){
                Color c = Color.WHITE; //Stock la couleurs utilisé pour le pion, couleurs qui varie en fonction des joueurs et de la disponibilitée de la case
                switch (gEngine.getPlayer(y, i)) { //Sélection de la couleur du pion
                    case 1:
                        c = Color.GREEN;
                        break;
                    
                    case 2:
                        c = Color.RED;
                        break;
                    
                    case 3:
                        c = Color.ORANGE;
                        break;
                
                    default:
                        c = Color.WHITE;
                        break;
                }
                playedGrid.add(new VuePlateau(c));
            }
        }
    }
    //Cette fonction permet de savoir quel joueur doit jouer
    private void updatePlayer(){
        if(gEngine.getNumberOfWinner()==2){canPlay=false;} //Détection de fin de partie (deux joueurs ont gagnés)
        else{
            for(int i=0; i<4; i++){ //Sélection du joueur qui doit jouer
                if(gEngine.getWinner()[0]==nPlaying || gEngine.getWinner()[1]==nPlaying){ //Parcours du tableau
                    nPlaying++;
                }
                if(nPlaying==4){nPlaying=1;} //Remise du compteur a 1 quand joueur = 4 (impossible)
            }
            setPlayerHolder(">> C'est au joueur " +nPlaying+" de jouer ! (Couleur : " + CcodeP[(nPlaying-1)] + " )");
        }
    }
    //Permet de mettre à jour le texte d'information en bas de la fenêtre
    public void setPlayerHolder(String text){
        GameHolder.setText(text);
    }
}
