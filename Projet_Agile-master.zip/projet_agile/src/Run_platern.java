public class Run_platern {

    Run_platern(){
         
        int pCount = 3; //Nombre de joueurs
        Pow4 jeu = new Pow4(pCount);
        Plateau p = new Plateau(jeu, pCount);
    }
}
