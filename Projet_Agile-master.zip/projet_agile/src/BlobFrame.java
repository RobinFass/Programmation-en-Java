import java.awt.BorderLayout;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class BlobFrame {
    //Fonctoin pour générer des fenêtre toute pétées avec du texte 
    BlobFrame(String text1, String text2, String title){
        JFrame win = new JFrame();
        win.setSize(370,250);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.add(new JLabel(text1), BorderLayout.NORTH);
        win.add(new JLabel(text2), BorderLayout.CENTER);
        win.setTitle(title);
        JButton close = new JButton("OK");
        close.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                win.dispose();
            }
        });
        win.add(close, BorderLayout.SOUTH);
        win.setVisible(true);
    }   
}
