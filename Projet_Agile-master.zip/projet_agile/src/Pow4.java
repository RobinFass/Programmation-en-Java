import java.util.Arrays; 

public class Pow4 {
    // Base 7 Hauteur 6
    private int[][] grille = new int [6][7];

    // mode de jeu (nombre de pion à aligné pour gagner)
    private int puissance;

    // nombre de tours joués
    private int tours;

    // Liste des gagnant
    private int[] gg = new int [2];

    // Nombre de gagnants
    private int ind = 0;

    /*
     * Prend en parametre le nombre de pion à aligné pour gagner
     * 
     * Initialisation des variables
     * 
     * Throw une exeption si la puissance dépasse 4
     */
    public Pow4(int NombreDeJoueur) throws IllegalArgumentException{
        // Zeroification de la grille
        for (int i=0; i<6; i++){
            for (int y=0;y<7;y++){
                this.grille[i][y]=0;
            }
        }

        // set de la puissance/mode de jeu inférieur à 5
        if (NombreDeJoueur==3){this.puissance=3;}
        else if (NombreDeJoueur==2){this.puissance=4;}
        else {throw new IllegalArgumentException("Puissance trop grande");}
            

        // set du nombre de tour joués
        this.tours=0;
    }

    /*
     * Prend en parametre la colonne et le joueur
     * 
     * Elle position le pion du joueur dans la colonne demander (si possible)
     * 
     * Renvoie un int si le pion à pu être poser (retour 0)
     * Impossible de posser le pion : -2
     * Double win : -1
     * Autrement : retour du joueur ayant gagné 
     */ 
    public int place(int col, int joueur){
        // compte le nombre de tours
        this.tours++;

        for(int i = 0; i<6;i++){

            // la colonne est pleine
            if(this.grille[i][col]!=0){
                return -2;
            }
            
            // pas de pion dans la colonne donc le pion est posé tout en bas
            else if (i==5){
                this.grille[i][col]=joueur;
                this.affichage();
                int winner = this.win(i, col);
                if (winner>0){
                    return joueur;
                }else if(winner==-1){
                    return winner;
                }
                return winner;
            }

            // detection d'un pion en dessous, pose du nouveau pion par dessus
            else if (this.grille[i+1][col]!=0){
                this.grille[i][col]=joueur;
                this.affichage();
                int winner = this.win(i, col);
                if (winner>0){
                    return joueur;
                }else if(winner==-1){
                    return winner;
                }
                return winner;
            }
        }
        return 0;
    }


    /*
     * Simple affichage de la grille
     */
    public void affichage(){
        if (this.tours>0){
            System.out.println("Tour numéro: "+this.tours);
        }
        System.out.println("+   +   +   +   +   +   +   +");
        for (int i=0; i<6; i++){
            System.out.print("| ");
            for (int y=0;y<7;y++){
                System.out.print(this.grille[i][y]+" | ");
            }
            System.out.println();
        }
        System.out.println("+---------------------------+\n");
    }

    /*
     * Prend en parametre i (la ligne) et y (la colonne), se sont les coordonnées d'une case
     * 
     * Cette fonction vérifie si la case fait partie d'une chaine victorieuse
     * 
     * Elle renvoie le numero du gagnant et -1 en cas de double victoire
     */
    public int win(int i, int y){
        // initialisation de winner
        int winner=0;

        // vérification de victoire sur chaque case
        winner=verif_autour(i, y);
        if (winner!=0){
            // mise en forme de la victoire
            this.gg[this.ind]=winner;
            if (this.ind==0){System.out.println("Le Joueur "+this.gg[this.ind]+" est le premier à avoir gagner !");}
            else {System.out.println("Le Joueur "+this.gg[this.ind]+" est le deuxieme à avoir gagner !");}
            
            // mise à jour du plateau après une victoire
            if(ind==0){
                this.update(winner);
                this.affichage();
                this.puissance++;
            }

            // indexage de la liste des gagants
            this.ind++;

            // vérification d'une victoire successive
            if (ind==1){
                for(int a=0;a<6;a++){
                    for(int b=0;b<7;b++){
                        int double_win = this.win(a, b);
                        if (double_win>0){
                            return winner;
                        }else if(double_win==-1){
                            ind++;
                            this.gg[this.ind]=double_win;
                            return double_win;
                        }
                    }
                }
            }
        }
        return winner;
    }

    /*
     * Prend en parametre i (la ligne) et y (la colonne), se sont les coordonnées d'une case
     * 
     * La fonction scan les cases alentoures de la case donnée.
     * Si la case donné voit un pion du même joueur qu'elle, elle prend le vecteur entre sa case et celle detectée
     * Puis le vecteur est répeté pour vérifier si d'autre pion du joueur sont dans le même axe
     * Une autre vérification est faite mais cette fois si avec le vecteur opposé
     * Cette vérification est faite dans le cas ou la case actuel n'est pas l'extrémitée de la chaine
     * Chaque case visité avec le pion du joueur est comptée
     * 
     * Renvoie 0 dans le cas ou la case n'est pas celle d'un joueur ou qu'il n'y a pas de chaine gagnante
     * Renvoie le numero du joueur en cas de chaine gagnante
     */
    public int verif_autour(int i, int y){
        int joueur=this.grille[i][y];

        // ne vérifie pas les cases sans pion
        if(joueur!=0){

            // scan les cases autour de la case visé
            for (int a=-1; a<2; a++){
                for (int b=-1;b<2;b++){
                    // permet de gerer les cas ou la vérification depasse la grille (les coins, les cotés) 
                    try{
                        // détéction d'un pion du même joueur que la case actuel
                        if (this.grille[i+a][y+b]==joueur && (a!=0 || b!=0)){
                            // compte a 2 parceque on compte le pion placer et le pion
                            // vérifier dans le if juste au dessus
                            // vecA et vecB *2 pour vérifier le 3eme pion
                            int compte=2,vecA=a*2,vecB=b*2;

                            // détéction d'une suite suivant un vecteur
                            for(int boucle=3;boucle<this.puissance+1;boucle++){
                                if(this.grille[i+vecA][y+vecB]==joueur){
                                    vecA=a*boucle;
                                    vecB=b*boucle;
                                    compte++;
                                } else {
                                    break;
                                }
                            }
                            if (compte==this.puissance){
                                return joueur;
                            }
                        }
                    }catch (ArrayIndexOutOfBoundsException e) {/*System.out.println("test");*/}
                    
                    // permet de gerer les cas ou la vérification depasse la grille (les coins, les cotés) 
                    try{
                        // détéction d'un pion du même joueur que la case actuel
                        if (this.grille[i+a][y+b]==joueur && (a!=0 || b!=0)){
                            // compte a 2 parceque on compte le pion placer et le pion
                            // vérifier dans le if juste au dessus
                            // vecA et vecB *2 pour vérifier le 3eme pion
                            int compte=2,vecA=a*2,vecB=b*2;
                            
                            vecA=-a;
                            vecB=-b;

                            // détéction d'une suite suivant le vecteur opposé au premier
                            for(int boucle=2;boucle<this.puissance+1;boucle++){
                                if(this.grille[i+vecA][y+vecB]==joueur){
                                    vecA=(-a)*boucle;
                                    vecB=(-b)*boucle;
                                    compte++;
                                } else {
                                    break;
                                }
                            }
                            
                            // vérification de victoire
                            if (compte==this.puissance){
                                return joueur;
                            }
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {;}
                }
            }
        }
        return 0;
    }

    /*
     * Prend un numero de joueur en parametre
     * 
     * La fonction met à 0 toutes les cases jouées par le joueur
     */
    public void zero_win(int joueur){
        for (int i=0; i<6; i++){
            for (int y=0;y<7;y++){
                if(this.grille[i][y]==joueur){
                    this.grille[i][y]=0;
                }
            }
        }
    }

    /*
     * Prend un numero de joueur en parametre
     * 
     * La fonction sert à simulé la gravité des pions suite à la suppression d'un joueur
     */
    public void update(int joueur){
        // suppression des pions d'un joueur
        zero_win(joueur);

        // boucle de 5 pour faire descendre un pion en haut d'une colonne tout en bas si possible
        for(int a=0;a<5;a++){
            for (int i=0; i<6; i++){
                for (int y=0;y<7;y++){
                    // permet de gere les cas ou les pions tout en bas regarde en dessous (hors de la grille)
                    try {
                        if(this.grille[i+1][y]==0){
                            // descente d'un pion et mise à 0 de son ancien emplacement
                            this.grille[i+1][y]=this.grille[i][y];
                            this.grille[i][y]=0;
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {}
                        
                }
            }
        }
    }

    //Cette fonction permet d'obtenir les informations d'une case (si un joueur a placé un pion et qui)
    public int getPlayer(int col, int ligne){
        return grille[ligne][col];
    }

    // getter de la liste des joueurs aillant gagnes
    public int[] getWinner(){
        return gg;
    }

    // getter du nombre de joueurs aillant gagnes
    public int getNumberOfWinner(){
        return ind;
    }
}