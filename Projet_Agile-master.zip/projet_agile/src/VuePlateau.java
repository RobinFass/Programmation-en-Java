import java.awt.*;
import javax.swing.*;

public class VuePlateau extends JComponent {
    private Color bgc;
    //Quand sumon de la fonction, la couleur du pinceau est set
    VuePlateau(Color s){
        bgc=s;
    }

    @Override
    protected void paintComponent(Graphics pinceau) {
        Graphics feutre = pinceau.create();
        feutre.setColor(bgc);
        //fillOval(<->, Hauteur, H, L)
        feutre.fillOval(0, 0, 75, 75);
    }
}