#!/bin/sh
# Script de lancement du programme
# <> : Défault -> Building
# <rebuild> : Recompille le prog
# <clean> : Nettoye les fichiers de compilation

if [ ! -f "Main.class" ] && [ "$1" != "clean" ] ;
then
	echo "Building..."
	/usr/bin/javac *.java
elif  [ "$1" = "rebuild" ];
then
	echo "Rebuilding...."
	rm -rf *.class
	/usr/bin/javac *.java
elif [ "$1" = "clean" ];
then 
    echo "Cleaning...."
    rm -rf *.class
    exit
fi
	/usr/bin/java "Main"
