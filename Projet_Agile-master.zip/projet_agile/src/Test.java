import java.util.Scanner;

public class Test{
    public static void main(String[] args) {
        Pow4 jeu = new Pow4(3);
        jeu.affichage();

        int col, joueur=1, tmp;

        //Fonction récupération des entrées utilisateurs
        while(true){
            if(jeu.getNumberOfWinner()==2){break;} //Détection de fin de partie (deux joueurs ont gagnés)
            for(int i=0; i<4; i++){ //Sélection du joueur qui doit jouer
                if(jeu.getWinner()[0]==joueur || jeu.getWinner()[1]==joueur){ //Parcours du tableau
                    joueur++;
                }
                if(joueur==4){joueur=1;} //Remise du compteur a 1 quand joueur = 4 (impossible)
            }

            System.out.print("C'est au joueur " + joueur + " de jouer : ");
            Scanner sc = new Scanner(System.in);
            col = sc.nextInt();

            //Détection pour éviter les arrays out of bonds exception
            if(col>=1 && col<=7){
                tmp = jeu.place(col-1, joueur); //Placement du pion
                // System.out.println(tmp+" reponse de jeu.place");
                if(tmp==0){joueur++;} //Emplacement libre
                else if(tmp==-1){break;} //Double win, fin de partie
                else if(tmp==-2){System.out.println("Impossible de placer le pion ici");}
            } 
            else{System.out.println("Impossible de placer le pion ici");}
        }
        

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        // // partie de puissance 4 battle royal normal
        // jeu.place(3,1);
        // jeu.place(3,2);
        // jeu.place(4,3);

        // jeu.place(2,1);
        // jeu.place(1,2);
        // jeu.place(2,3);

        // jeu.place(3,1);
        // jeu.place(4,2);
        // jeu.place(3,3);


        // jeu.place(4,1);
        // jeu.place(2,2);
        // jeu.place(5,3);

        // jeu.place(4,1);
        // jeu.place(5,2);
        

        // // joueur 2 gagne le puissance 3

        // jeu.place(5,3);

        // jeu.place(1,1);
        // jeu.place(5,3);

        // jeu.place(5,1);

        // // joueur 1 gagne le puissance 4

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        // // partie de puissance 4 battle royal truquée victoire du joueur 1 apres la victoire du joueur 
        // jeu.place(3,1);
        // jeu.place(3,1);
        // jeu.place(3,2);
        // jeu.place(3,1);
        // jeu.place(3,1);


        // jeu.place(4,1);
        // jeu.place(4,1);
        

        // jeu.place(5,3);
        // jeu.place(5,3);
        // jeu.place(5,2);

        // jeu.place(4,2);

        // // victoire du joueur 2

        // // victoire du joueur 1 (gravité)

        ///////////////////////////////////////////////////////////////////////////////////////////////////

    }
}