import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Controleur extends JPanel implements ActionListener, MouseListener{
	private Combinaison maitre;
	private Combinaison[] prop;
	private Combinaison[] rep;
	private int index;
	private VueJoueur buttonjoueur;
	private JPanel plateau;
	private boolean gagner;

    @Override
    public void actionPerformed(ActionEvent evenement){
        String i = evenement.getActionCommand();
        if (i=="Vérifier"){
			if(index<10){
				if(prop[index].getindex()==5){
					this.proposer(prop[index]);
					plateau.add(new VuePlateau(prop,rep,index));
					index++;
				}
				else if (gagner){
					for(int j=0;j<10;j++){
						prop[j].effacer();
						rep[j].effacer();
					}
					index=0;
					maitre.random(5);
					gagner=false;
				}
			}
			else{
				for(int j=0;j<10;j++){
					prop[j].effacer();
					rep[j].effacer();
				}
				index=0;
				maitre.random(5);
			}
		}
        else if (i=="Effacer"){
			if(!gagner && index<10){
				prop[index].effacer();
				repaint();
			}
		}
        else if (i=="Aléatoire"){
			if(!gagner && index<10){
				prop[index].random(prop[index].getindex());
				repaint();
			}
		}
    }
	public void mouseClicked(MouseEvent e) {}  
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {
		Color actuelle = Color.LIGHT_GRAY;
		if (e.getComponent().equals(buttonjoueur.getColor(0))){
			actuelle = Color.BLUE;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(1))){
			actuelle = Color.GREEN;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(2))){
			actuelle = Color.MAGENTA;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(3))){
			actuelle = Color.ORANGE;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(4))){
			actuelle = Color.RED;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(5))){
			actuelle = Color.PINK;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(6))){
			actuelle = Color.YELLOW;
		}
		else if(e.getComponent().equals(buttonjoueur.getColor(7))){
			actuelle = Color.DARK_GRAY;
		}
		prop[index].add(actuelle);
		plateau.add(new VuePlateau(prop,rep,index));
		repaint();
	}
    public void mouseReleased(MouseEvent e) {}

	public Controleur(JFrame jf){
		maitre = new Combinaison();
		maitre.random(0);
		index=0;

		// set les prpositions et les reponses
		prop = new Combinaison[10];
		rep = new Combinaison[10];
		for(int i=0;i<10;i++){
			prop[i] = new Combinaison();
			rep[i] = new Combinaison();
		}

		JPanel player = new JPanel();
		JPanel boutons = new JPanel();
		JPanel couleurs = new JPanel();
		plateau = new JPanel();
		buttonjoueur = new VueJoueur();

		this.setLayout(new GridLayout(1,2));
		this.add(player);
		this.add(plateau);

		player.setLayout(new GridLayout(3,1));
        player.add(couleurs);
        player.add(boutons);
		JTextArea jta = new JTextArea();
		jta.append("               Appuyer sur 'Vérifier' puis 'Effacer'\n               pour recommencer une parite fini.");
		jta.setBackground(new Color(238,238,238));
		player.add(jta);

		couleurs.setLayout(new GridLayout(2,4));
		plateau.setLayout(new GridLayout(10,2));
        
		for(int i=0;i<8;i++){
            buttonjoueur.getColor(i).addMouseListener(this);
			couleurs.add(buttonjoueur.getColor(i));
        }

		for(int i=0; i<10; i++){
			plateau.add(new VuePlateau(prop,rep,i));
		}

		boutons.add(buttonjoueur.getv());
        boutons.add(buttonjoueur.gete());
        boutons.add(buttonjoueur.geta());

		buttonjoueur.getv().addActionListener(this);
		buttonjoueur.gete().addActionListener(this);
		buttonjoueur.geta().addActionListener(this);
	}


	//proposer s'appelle quand on valide une combinaison, elle la teste et affiche la réponse.
	//C'est également là que le controleur détermine s'il y a un gagnant. 
	private void proposer(Combinaison c){
		rep[index]=maitre.comparer(prop[index]);

		repaint();

		gagner = maitre.gagner(rep[index]);
		if(index <= 9 && gagner == true){
			System.out.println("Win in "+(index+1)+" tries !");
		}
		else if (index == 9 && gagner == false){
			System.out.println("Lose");
		}
	}
}
