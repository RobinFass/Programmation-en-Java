import javax.swing.*;
import java.awt.*;

public class VueCouleur extends JComponent{
    private Color couleur;
    
    public VueCouleur(Color c){
        super();
        this.couleur = c;
    }

    @Override
    protected void paintComponent(Graphics pinceau){
        Graphics secondPinceau = pinceau.create();
    
        if (this.isOpaque()) {
        secondPinceau.setColor(this.getBackground());
        secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
        }
        secondPinceau.setColor(couleur);
        secondPinceau.fillArc(10,10,50,50,0,360);
    }
}