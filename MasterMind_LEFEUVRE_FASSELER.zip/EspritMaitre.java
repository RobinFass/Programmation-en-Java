import javax.swing.*;
import java.awt.*;

public class EspritMaitre{
		public static void main(String[] args){
        JFrame fen = new JFrame();
        fen.setLocation(300,100);
        fen.setSize(800,500);
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Controleur controleur = new Controleur(fen);
        fen.add(controleur);

        fen.setVisible(true);
	}
}