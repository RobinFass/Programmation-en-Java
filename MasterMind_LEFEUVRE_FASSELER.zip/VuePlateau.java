import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VuePlateau extends JPanel{
	private Combinaison[] atta;
	private Combinaison[] def;
	private int index;


	public VuePlateau(Combinaison[] p, Combinaison[] r, int ind){
		super();
		this.atta=p;
		this.def=r;
		index=ind;
    }

	@Override
	protected void paintComponent(Graphics pinceau){
		Graphics secondPinceau = pinceau.create();
	
		if (this.isOpaque()) {
		secondPinceau.setColor(this.getBackground());
		secondPinceau.fillRect(0, 0, this.getWidth(), this.getHeight());
		}

		for(int j=0;j<5;j++){
			secondPinceau.setColor(atta[index].getColor(j));
			secondPinceau.fillArc(0+29*j,4,29,29,0,360);
			secondPinceau.setColor(def[index].getColor(j));
			secondPinceau.fillArc(30*5+5+14*j,12,14,14,0,360);
		}
	}
}