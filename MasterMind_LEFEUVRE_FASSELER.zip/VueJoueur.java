import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VueJoueur extends JPanel{
    private JButton v;
    private JButton e;
    private JButton a;
    private VueCouleur[] TabCouleur;


    public VueJoueur(){
        super();
        TabCouleur = new VueCouleur[8];
        Color[] couleur={Color.BLUE,Color.GREEN,Color.MAGENTA,Color.ORANGE,Color.RED,Color.PINK,Color.YELLOW,Color.DARK_GRAY};

        for(int i=0;i<8;i++){
            this.TabCouleur[i] = new VueCouleur(couleur[i]);
        }
        
        v = new JButton("Vérifier");
        e = new JButton("Effacer");
        a = new JButton("Aléatoire");
    }

    public JButton getv(){
        return v;
    }
    public JButton geta(){
        return a;
    }
    public JButton gete(){
        return e;
    }

    public VueCouleur getColor(int i){
        if (i >= 0 && i <= 7){
            return this.TabCouleur[i];
        }
        else{
            throw new IllegalStateException("Index trop grand");
        }
    }
}