import java.awt.*;

public class Combinaison {
	//choix contient les pions de la combinaison
	protected Color[] choix;
	//index contient le nombre de pions ajoutés à la combinaison
	protected int index;


	// créer une combinaison vide
	public Combinaison(){
		choix = new Color[5];
		for(int i=0;i<5;i++){
			choix[i]=Color.LIGHT_GRAY;
		}
		index=0;
	}


	// recréer la même combinaison passer en parametre 
	public Combinaison(Combinaison c){
		choix = new Color[5];
		for(int i=0;i<5;i++){
			choix[i]=c.choix[i];
		}
		index=5;
	}


	// réinitialise une combinaison
	public void effacer(){
		for(int i=0;i<5;i++){
			this.choix[i]=Color.LIGHT_GRAY;
		}
		index = 0;
	}


	// add ajoute une couleur à la combinaison
	public void add (Color c) throws IllegalStateException{
		if (index<5){
			choix[index]=c;
			index++;
		}
	}


	// getter de index
	public int getindex(){
		return index;
	}

	// créer une combinaison aléatoire parmis les 8 couleurs disponibles 
	public void random(int ind){
		Color[] couleur={Color.BLUE,Color.GREEN,Color.MAGENTA,Color.ORANGE,Color.RED,Color.PINK,Color.YELLOW,Color.DARK_GRAY};
		int rdm;
		if (ind == 5){
			this.effacer();
			ind=0;
		}
		for(int i=ind;i<5;i++){
			rdm=(int) (Math.random()*8);
			this.add(couleur[rdm]);
		}
	}


	// comparer compare la combinaison avec une autre donnée en argument. 
	// Elle renvoie la réponse, càd une combinaison contenant des couleurs noires, blancs ou grisclair. 
	public Combinaison comparer(Combinaison c){
		Combinaison fin = new Combinaison();
		Combinaison clone = new Combinaison();

		// initialise le clone et la combinaison de fin
		for(int i=0;i<5;i++){
			clone.add(this.choix[i]);
			fin.add(Color.LIGHT_GRAY);
		}

		// vérifie les couleur bien placées
		for(int i=0; i<5;i++){
			if(c.choix[i].equals(this.choix[i])){
				fin.choix[i]=Color.black;
				clone.choix[i]=Color.LIGHT_GRAY; // signifie couleur déjà vérifié dans le clone
			}
		}

		// vérifie les couleurs pas bien placées
		for(int i=0; i<5;i++){
			for(int y=0; y<5;y++){
				if(c.choix[i].equals(clone.choix[y])){
					if(!fin.choix[i].equals(Color.BLACK)){ // ne pas changer une couleur deja verifier 
						fin.choix[i]=Color.white;
						clone.choix[y]=Color.LIGHT_GRAY;
						break;
					}
				}
			}
		}
		return fin;
	}


	// gagner test si une combinaison réponse (obtenue via comparer) est gagnante
	public boolean gagner(Combinaison c){
		// initialise le clone
		Combinaison clone = new Combinaison(c);

		// change la main du joueur si la couleur est bien placée
		for(int i=0; i<5;i++){
			if(c.choix[i].equals(this.choix[i])){
				clone.choix[i]=Color.black;
			}
		}
		boolean test=true;

		// vérifie si toute les couleurs sont bien placées
		for(int i=0;i<5;i++){
			if(!clone.choix[i].equals(Color.BLACK)){
				test=false;
			}
		}
		return test;
	}


	// renvoie la couleur
	public Color getColor(int i){
		Color c = new Color(this.choix[i].getRGB());
		return c;
	}


	public String toString(){
		String s="Combinaison : ";
		for(int i=0;i<5;i++){
			if(choix[i].equals(Color.blue)){s+="Bleu, ";}
			if(choix[i].equals(Color.green)){s+="Vert, ";}
			if(choix[i].equals(Color.magenta)){s+="Magenta, ";}
			if(choix[i].equals(Color.orange)){s+="Orange, ";}
			if(choix[i].equals(Color.red)){s+="Rouge, ";}
			if(choix[i].equals(Color.pink)){s+="Rose, ";}
			if(choix[i].equals(Color.yellow)){s+="Jaune, ";}
			if(choix[i].equals(Color.darkGray)){s+="Gris, ";}
			if(choix[i].equals(Color.black)){s+="Bien placé, ";}
			if(choix[i].equals(Color.white)){s+="Mal placé, ";}
			if(choix[i].equals(Color.lightGray)){s+="Absent, ";}
		}
		return s;
	}
}